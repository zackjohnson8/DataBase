COMPILE:

g++ main.cpp
./a.out
or also
./a.out <file name>
